<?php

return array('
a{f:base()}b');

?>
