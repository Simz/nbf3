<?php

return array(
	'<f:format.printf arguments="{number : 362525200}">',
	'%.3e',
	'</f:format.printf>'
);

?>
