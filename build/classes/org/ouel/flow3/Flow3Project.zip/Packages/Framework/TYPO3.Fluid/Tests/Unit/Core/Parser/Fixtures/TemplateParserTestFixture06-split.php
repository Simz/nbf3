<?php

return array('{namespace foo=TYPO3\Fluid\ViewHelpers}<foo:format.nl2br><foo:format.number decimals="1">{number}</foo:format.number></foo:format.nl2br>');

?>
