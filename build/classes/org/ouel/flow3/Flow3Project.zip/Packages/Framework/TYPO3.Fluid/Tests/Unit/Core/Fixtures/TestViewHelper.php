<?php
namespace TYPO3\Fluid\Core\Fixtures;

class TestViewHelper extends \TYPO3\Fluid\Core\ViewHelper\AbstractViewHelper {

	/**
	 * My comments. Bla blubb.
	 *
	 * @param integer $param1 P1 Stuff
	 * @param array $param2 P2 Stuff
	 * @param string $param3 P3 Stuff
	 */
	public function render($param1, array $param2, $param3 = "default") {

	}
}

?>